#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 	: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

echo "This runs all the setup scripts on all githubs"

count=0

for name in $(ls -d */); do
	count=$[count+1]
	cd $name
	tput setaf 1;echo "Github "$count" - "$name;tput sgr0;
	sh ./setup*
	echo "#################################################"
	echo "################  "$(basename `pwd`)" done"
	echo "#################################################"
	cd ..
done
