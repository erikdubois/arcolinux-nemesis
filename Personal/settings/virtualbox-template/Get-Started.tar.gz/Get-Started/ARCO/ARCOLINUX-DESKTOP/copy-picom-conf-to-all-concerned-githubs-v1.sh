#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

# we start with picom.conf in desktop

source="/home/erik/ARCO/ARCOLINUX-DESKTOP/picom.conf"
destination=(
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-awesome/etc/skel/.config/awesome/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-bspwm/etc/skel/.config/bspwm/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-cwm/etc/skel/.config/cwm/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-dusk/etc/skel/.config/arco-dusk/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-dwm/etc/skel/.config/arco-dwm/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-dwm-nemesis/etc/skel/.config/arco-dwm/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-enlightenment/etc/skel/.e/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-fvwm3/etc/skel/.config/fvwm3/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-i3wm/etc/skel/.config/i3/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-icewm/etc/skel/.config/icewm/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-jwm/etc/skel/.config/jwm/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-lxqt/etc/skel/.config/lxqt/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-openbox/etc/skel/.config/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-openbox-xtended/etc/skel/.config/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-qtile/etc/skel/.config/qtile/scripts/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-spectrwm/etc/skel/.config/spectrwm/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-sway/etc/skel/.config/sway/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-wmderland/etc/skel/.config/wmderland/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-xmonad-polybar/etc/skel/.xmonad/scripts/picom.conf
/home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-xmonad-xmobar/etc/skel/.xmonad/scripts/picom.conf
)


echo "Leftwm and Herbstluftwm special treatment"
# /home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-leftwm/etc/skel/.config/leftwm/themes/candy/picom.conf
# /home/erik/ARCO/ARCOLINUX-DESKTOP/arcolinux-herbstluftwm/etc/skel/.config/herbstluftwm/picom.conf

count=0

for name in "${destination[@]}"; do
	count=$[count+1]
	echo $count	
	sourceFile=$source
	echo "Source :           "$sourceFile
	targetFile=$name
	echo "Destination :      "$targetFile
	echo
	cp -v $sourceFile $targetFile
done

echo
echo "Leftwm and Herbstluftwm special treatment"