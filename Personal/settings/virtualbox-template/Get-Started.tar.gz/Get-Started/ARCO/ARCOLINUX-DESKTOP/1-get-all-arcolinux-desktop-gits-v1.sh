#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 	: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

echo "This updates the existing githubs"
echo "Fill the array with the original folders first"

# use ls -d */ > list to get the list of the created githubs and copy/paste in

directories=(
arcolinux-awesome/
arcolinux-berry/
arcolinux-bspwm/
arcolinux-budgie/
arcolinux-cinnamon/
arcolinux-chadwm/
arcolinux-chadwm-nemesis/
arcolinux-cutefish/
arcolinux-cwm/
arcolinux-deepin/
arcolinux-dusk/
arcolinux-dusk-nemesis/
arcolinux-dwm/
arcolinux-dwm-nemesis/
arcolinux-enlightenment/
arcolinux-fvwm3/
arcolinux-gnome/
arcolinux-herbstluftwm/
arcolinux-hypr/
arcolinux-hyprland/
arcolinux-i3wm/
arcolinux-i3wm-db-nemesis/
arcolinux-i3wm-forest/
arcolinux-icewm/
arcolinux-jwm/
arcolinux-leftwm/
arcolinux-lxqt/
arcolinux-mate/
arcolinux-newm/
arcolinux-openbox/
arcolinux-openbox-xtended/
arcolinux-plasma/
arcolinux-plasma-nemesis/
arcolinux-qtile/
arcolinux-qtile-dots/
arcolinux-river/
arcolinux-spectrwm/
arcolinux-sway/
arcolinux-ukui/
arcolinux-wayfire/
arcolinux-worm/
arcolinux-wmderland/
arcolinux-xfce/
arcolinux-xfce-nemesis/
arcolinux-xmonad-polybar/
arcolinux-xmonad-xmobar/
)

count=0

for name in "${directories[@]}"; do
	count=$[count+1]
	tput setaf 1;echo "Github "$count;tput sgr0;
	# if there is no folder then make one
	git clone https://github.com/arcolinux/$name
	echo "#################################################"
	echo "################  "$(basename `pwd`)" done"
	echo "#################################################"
done
