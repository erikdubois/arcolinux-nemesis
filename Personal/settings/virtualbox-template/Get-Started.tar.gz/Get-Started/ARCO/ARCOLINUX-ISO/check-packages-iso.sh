#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 	: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

#tput setaf 0 = black 
#tput setaf 1 = red 
#tput setaf 2 = green
#tput setaf 3 = yellow 
#tput setaf 4 = dark blue 
#tput setaf 5 = purple
#tput setaf 6 = cyan 
#tput setaf 7 = gray 
#tput setaf 8 = light blue

# use ls -d */ > list to get the list of the created githubs and copy/paste in
# in /home/erik/ARCO/ARCOLINUX-PKGBUILD/arcolinux-pkgbuild-3party/ArcoLinux_3th_party/

count=0

directories=(
adobe-source-sans-fonts
alacritty
alacritty-themes
appstream
arandr
arc-gtk-theme
archiso
arcolinux-fish-git
arcolinux-meta-log
arcolinux-pamac-all
asciinema
awesome-terminal-fonts
baobab
base16-alacritty-git
bash-completion
bat
bibata-cursor-theme-bin
catfish
conky-lua-archers
cronie
dconf-editor
dex
discord
dmenu
downgrade
duf
edid-decode-git
evince
expac
feh
file-roller
firefox
fish
font-manager
galculator
git
gitahead-bin
gksu
gnome-disk-utility
gnome-keyring
gnome-screenshot
gnome-software
gnome-software-packagekit-plugin
gparted
gpick
grsync
grub-customizer
gtop
gufw
guvcview
hardcode-fixer-git
hardinfo-gtk3
hddtemp
htop
hunspell
hunspell-en_US
hw-probe
hyphen
hyphen-en
imagemagick
intltool
inxi
iw
jq
jsoncpp
kvantum
laptop-detect
libmtp
lm_sensors
lsb-release
lshw
meld
mintstick-git
mkinitcpio-openswap
mlocate
neofetch
nomacs
noto-fonts
numix-circle-arc-icons-git
numix-circle-icon-theme-git
numix-icon-theme-git
numlockx
oh-my-zsh-git
p7zip
pace
paru-bin
pkgfile
plank
playerctl
polkit
polkit-gnome
pragha
pulseaudio-equalizer-ladspa
python-pyparted
python-pywal
qbittorrent
qt5ct
rate-mirrors-bin
ripgrep
ripgrep-all
rxvt-unicode
sardi-icons
scour
scrot
simple-scan
simplescreenrecorder
sparklines-git
speedtest-cli-git
sublime-text-4
surfn-icons-git
telegram-desktop
the_platinum_searcher-bin
the_silver_searcher
time
tlp
ttf-bitstream-vera
ttf-dejavu
ttf-droid
ttf-font-awesome
ttf-hack
ttf-inconsolata
ttf-liberation
ttf-ms-fonts
ttf-roboto
ttf-roboto-mono
ttf-ubuntu-font-family
ufw
unace
unrar
unzip
urxvt-fullscreen
urxvt-perls
urxvt-resize-font-git
variety
vimix-cursors
vlc
w3m
webkit2gtk
wmctrl
wttr
xapp
xdg-desktop-portal-gtk
xdo
xdotool
yad
yay-bin
yt-dlp
zenity
zsh
zsh-completions
zsh-syntax-highlighting
)

#for name in $(ls -d */); do

path="/home/erik/ARCO/ARCOLINUX-CAL/arcob-calamares-config-awesome/calamares/modules/"

for name in "${directories[@]}"; do
	count=$[count+1]
	echo
	echo
	tput setaf 2;
	echo "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
	echo "Package nr $count: "$name
	echo "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
	tput sgr0;

	rg $name $path
	
	tput setaf 3;
	echo "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
	echo "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
	tput sgr0;
	echo
	echo
	echo

done
