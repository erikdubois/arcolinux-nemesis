#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

source="/home/erik/ARCO/ARCOLINUXB/arco-awesome/archiso/packages-personal-repo.x86_64"

echo "Copying from here... "
echo $source "to all githubs"
echo "press a key"
read
dirs=$(echo arco*/)
for dir in $dirs
do
	echo
	echo "copy " $source
	echo " to "
	echo $dir"archiso/"
	echo
	cp -v $source $dir"archiso/"
done
