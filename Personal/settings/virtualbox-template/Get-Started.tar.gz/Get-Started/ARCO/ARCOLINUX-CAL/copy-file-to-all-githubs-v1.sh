#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

# never login.yaml

#source="/home/erik/ARCO/ARCOLINUX-CAL/arcob-calamares-config-awesome/calamares/modules/netinstall-gaming.yaml"
#source="/home/erik/ARCO/ARCOLINUX-CAL/arcob-calamares-config-awesome/calamares/modules/netinstall-office.yaml"
#source="/home/erik/ARCO/ARCOLINUX-CAL/settings-advanced-no-nivida.conf"
#source="/home/erik/ARCO/ARCOLINUX-CAL/arco-calamares-config-xl-next/calamares/modules/partition.conf"
source="/home/erik/ARCO/ARCOLINUX-CAL/arcob-calamares-config-awesome/calamares/modules/netinstall-desktop.yaml"


echo "Copying from here... "
echo $source "to all githubs"
echo "press a key"
read
dirs=$(echo arco*/)
for dir in $dirs
do
	echo
	echo "copy " $source
	echo " to "
	echo
	cp -v $source $dir"calamares/modules/"
done
