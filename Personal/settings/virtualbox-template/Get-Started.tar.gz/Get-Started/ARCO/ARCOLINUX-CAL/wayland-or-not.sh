#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

echo "What do you want to replace?"
FIND="  - netinstall@desktop-wayland"
#FIND="##- netinstall@desktop-wayland"
echo "What do you want to replace it with?"
REPLACE="#  - netinstall@desktop-wayland"
#REPLACE="- netinstall@desktop-wayland"

find .  -name "settings-advanced-no-nivida.conf" -type f -exec sed -i "s/$FIND/$REPLACE/g" {} \;
