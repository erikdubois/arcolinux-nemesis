#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

sh /home/erik/ARCO/ARCOLINUX-CAL/copy-awesome-calamares-yaml-to-all-Bs.sh
sh /home/erik/ARCO/ARCOLINUX-CAL/copy-xl-calamares-yaml-to-all-XLs.sh
sh /home/erik/ARCO/ARCOLINUX-CAL/copy-xs-calamares-yaml-to-all-XSs.sh
sh /home/erik/ARCO/ARCOLINUX-CAL/copy-d-calamares-yaml-to-all-Ds.sh