#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

source="/home/erik/ARCO/ARCOLINUX-CAL/"

directories=(
arco-calamares-config-xs/
arco-calamares-config-xs-lts/
arco-calamares-config-xs-xanmod/
arco-calamares-config-xs-zen/
)

# netinstall-kernel.yaml
# netinstall-arcolinuxdev.yaml

files=(
netinstall-applications.yaml
netinstall-arcolinux.yaml
netinstall-communication.yaml
netinstall-desktop.yaml
netinstall-desktop-wayland.yaml
netinstall-development.yaml
netinstall-drivers.yaml
netinstall-filemanagers.yaml
netinstall-fonts.yaml
netinstall-gaming.yaml
netinstall-graphics.yaml
netinstall-internet.yaml
netinstall-login.yaml
netinstall-multimedia.yaml
netinstall-nvidia.yaml
netinstall-office.yaml
netinstall-terminals.yaml
netinstall-theming.yaml
netinstall-usb.yaml
netinstall-utilities.yaml
)

count=0

for name in "${directories[@]}"; do
	count=$[count+1]
	echo $count " - " $name

	for file in "${files[@]}"; do

		sourceFile=$source"arco-calamares-config-xl/calamares/modules/"$file
		echo "      "$sourceFile
		targetFile=$source$name"calamares/modules/"$file
		echo "      "$targetFile
		cp $sourceFile $targetFile
	done
done
