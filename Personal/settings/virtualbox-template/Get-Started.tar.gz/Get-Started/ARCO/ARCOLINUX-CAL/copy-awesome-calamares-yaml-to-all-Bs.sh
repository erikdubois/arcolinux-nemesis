#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

source="/home/erik/ARCO/ARCOLINUX-CAL/"

directories=(
arcob-calamares-config-berry/
arcob-calamares-config-bspwm/
arcob-calamares-config-budgie/
arcob-calamares-config-chadwm/
arcob-calamares-config-cinnamon/
arcob-calamares-config-cutefish/
arcob-calamares-config-cwm/
arcob-calamares-config-deepin/
arcob-calamares-config-dusk/
arcob-calamares-config-dwm/
arcob-calamares-config-enlightenment/
arcob-calamares-config-everyway/
arcob-calamares-config-fvwm3/
arcob-calamares-config-gnome/
arcob-calamares-config-herbstluftwm/
arcob-calamares-config-hypr/
arcob-calamares-config-hyprland/
arcob-calamares-config-i3/
arcob-calamares-config-icewm/
arcob-calamares-config-jwm/
arcob-calamares-config-leftwm/
arcob-calamares-config-lxqt/
arcob-calamares-config-mate/
arcob-calamares-config-openbox/
arcob-calamares-config-pantheon/
arcob-calamares-config-plasma/
arcob-calamares-config-qtile/
arcob-calamares-config-spectrwm/
arcob-calamares-config-sway/
arcob-calamares-config-ukui/
arcob-calamares-config-wmderland/
arcob-calamares-config-worm/
arcob-calamares-config-xfce/
arcob-calamares-config-xmonad/
arcob-calamares-config-xtended/
)

files=(
netinstall-applications.yaml
netinstall-arcolinux.yaml
netinstall-arcolinuxdev.yaml
netinstall-communication.yaml
netinstall-desktop.yaml
netinstall-desktop-wayland.yaml
netinstall-development.yaml
netinstall-drivers.yaml
netinstall-filemanagers.yaml
netinstall-fonts.yaml
netinstall-gaming.yaml
netinstall-graphics.yaml
netinstall-internet.yaml
netinstall-kernel.yaml
netinstall-login.yaml
netinstall-multimedia.yaml
netinstall-nvidia.yaml
netinstall-office.yaml
netinstall-terminals.yaml
netinstall-theming.yaml
netinstall-usb.yaml
netinstall-utilities.yaml
)

count=0

for name in "${directories[@]}"; do
	count=$[count+1]
	echo $count " - " $name

	for file in "${files[@]}"; do

		sourceFile=$source"arcob-calamares-config-awesome/calamares/modules/"$file
		echo "      "$sourceFile
		targetFile=$source$name"calamares/modules/"$file
		echo "      "$targetFile
		cp $sourceFile $targetFile
	done
done
