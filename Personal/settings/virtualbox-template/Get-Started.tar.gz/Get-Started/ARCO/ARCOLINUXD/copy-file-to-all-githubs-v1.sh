#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

echo "what file to copy"
#read FIND
FIND="/home/erik/ARCO/ARCOLINUXD/140-printers.sh"
dirs='echo */'
#echo $dirs
for dir in $dirs
do
	cp -v $FIND $dir
done
