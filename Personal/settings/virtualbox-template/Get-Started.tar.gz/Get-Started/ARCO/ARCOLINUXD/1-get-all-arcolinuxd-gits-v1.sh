#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 	: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

echo "This updates the existing githubs"
echo "Fill the array with the original folders first"

# use ls -d */ > list to get the list of the created githubs and copy/paste in

directories=(
arco-awesome/
arco-berry/
arco-bspwm/
arco-budgie/
arco-cinnamon/
arco-chadwm/
arco-cwm/
arco-cutefish/
arco-deepin/
arco-dusk/
arco-dwm/
arco-enlightenment/
arco-fvwm3/
arco-gnome/
arco-herbstluftwm/
arco-hypr/
arco-hyprland/
arco-i3/
arco-icewm/
arco-jwm/
arco-leftwm/
arco-lxqt/
arco-mate/
arco-openbox/
arco-pantheon/
arco-plasma/
arco-qtile/
arco-spectrwm/
arco-sway/
arco-ukui/
arco-worm/
arco-wmderland/
arco-xfce/
arco-xmonad/
)



count=0

for name in "${directories[@]}"; do
	count=$[count+1]
	tput setaf 1;echo "Github "$count;tput sgr0;
	# if there is no folder then make one
	git clone https://github.com/arcolinuxd/$name
	echo "#################################################"
	echo "################  "$(basename `pwd`)" done"
	echo "#################################################"
done
