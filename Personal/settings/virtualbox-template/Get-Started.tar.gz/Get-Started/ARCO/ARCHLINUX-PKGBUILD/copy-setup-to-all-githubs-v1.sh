#!/bin/bash
#
#tput setaf 0 = black
#tput setaf 1 = red
#tput setaf 2 = green
#tput setaf 3 = yellow
#tput setaf 4 = dark blue
#tput setaf 5 = purple
#tput setaf 6 = cyan
#tput setaf 7 = gray
#tput setaf 8 = light blue
##################################################################################################################
# Written to be used on 64 bits computers
# Author 		: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

direct=$(basename `pwd`)
source="/home/erik/ARCO/$direct/setup-our-git-credentials.sh"

echo "Copying from here... "
echo $source "to all directories - githubs"
echo "press a key"
read
dirs=$(echo */)
for dir in $dirs
do
	echo
	echo "copy " $source
	echo " to "
	echo $dir
	echo
	cp -v $source $dir
done
