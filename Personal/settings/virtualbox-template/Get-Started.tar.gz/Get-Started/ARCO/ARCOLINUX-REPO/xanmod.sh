#!/bin/bash

echo "######################################"
echo "ATT - FIRST CHAOTICS REPO ON and ARCO OFF"
echo "######################################"
echo "Cache WILL BE cleaned (y/n)"

read response

if [[ "$response" == [yY] ]]; then
	sudo pacman -Scc
fi

echo "######################################"
echo "Updating pacman"
sudo pacman -Syy
echo

echo "######################################"
echo "Removing old files"
echo

rm /home/erik/ARCO/ARCOLINUX-REPO/testing/*

echo "######################################"
echo "Download Xanmod kernel (y/n)"

read response

if [[ "$response" == [yY] ]]; then
	sudo pacman -Syw linux-xanmod --noconfirm
	sudo pacman -Syw linux-xanmod-headers --noconfirm
	sudo cp -v /var/cache/pacman/pkg/linux-xanmod-6* /home/erik/ARCO/ARCOLINUX-REPO/testing/
	sudo cp -v /var/cache/pacman/pkg/linux-xanmod-headers-6* /home/erik/ARCO/ARCOLINUX-REPO/testing/
	sudo cp -v /var/cache/pacman/pkg/linux-xanmod-6* /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod/
	sudo cp -v /var/cache/pacman/pkg/linux-xanmod-headers-6* /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod/
	sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-REPO/testing/linux-xanmod*
	sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod/linux-xanmod*
fi

echo "######################################"
echo "Download Xanmod-lts kernel (y/n)"
echo "######################################"

read response

if [[ "$response" == [yY] ]]; then
sudo pacman -Syw linux-xanmod-lts --noconfirm
sudo pacman -Syw linux-xanmod-lts-headers --noconfirm
sudo cp -v /var/cache/pacman/pkg/linux-xanmod-lts* /home/erik/ARCO/ARCOLINUX-REPO/testing/
sudo cp -v /var/cache/pacman/pkg/linux-xanmod-lts* /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod-lts/
sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-REPO/testing/linux-xanmod*
sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod-lts/linux-xanmod*
fi

echo "######################################"
echo "Download Xanmod-rt kernel (y/n)"
echo "######################################"

read response

if [[ "$response" == [yY] ]]; then
sudo pacman -Syw linux-xanmod-rt --noconfirm
sudo pacman -Syw linux-xanmod-rt-headers --noconfirm
sudo cp -v /var/cache/pacman/pkg/linux-xanmod-rt* /home/erik/ARCO/ARCOLINUX-REPO/testing/
sudo cp -v /var/cache/pacman/pkg/linux-xanmod-rt* /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod-rt/
sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-REPO/testing/linux-xanmod*
sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod-rt/linux-xanmod*
fi

echo "######################################"
echo "Download Xanmod-tt kernel (y/n)"
echo "######################################"

read response

if [[ "$response" == [yY] ]]; then
sudo pacman -Syw linux-xanmod-tt --noconfirm
sudo pacman -Syw linux-xanmod-tt-headers --noconfirm
sudo cp -v /var/cache/pacman/pkg/linux-xanmod-tt* /home/erik/ARCO/ARCOLINUX-REPO/testing/
sudo cp -v /var/cache/pacman/pkg/linux-xanmod-tt* /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod-tt/
sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-REPO/testing/linux-xanmod*
sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod-tt/linux-xanmod*
fi

echo "######################################"
echo "Download Xanmod-anbox kernel (y/n)"
echo "######################################"

read response

if [[ "$response" == [yY] ]]; then
sudo pacman -Syw linux-xanmod-anbox --noconfirm
sudo pacman -Syw linux-xanmod-anbox-headers --noconfirm
sudo cp -v /var/cache/pacman/pkg/linux-xanmod-anbox* /home/erik/ARCO/ARCOLINUX-REPO/testing/
sudo cp -v /var/cache/pacman/pkg/linux-xanmod-anbox* /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod-anbox/
sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-REPO/testing/linux-xanmod*
sudo chown erik:erik /home/erik/ARCO/ARCOLINUX-ARCHIVE/packages/l/linux-xanmod-anbox/linux-xanmod*
fi