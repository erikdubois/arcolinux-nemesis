#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 	: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

echo "This updates the existing githubs"
echo "Fill the array with the original folders first"

# use ls -d */ > list to get the list of the created githubs and copy/paste in

directories=(
arcolinux-arc-aqua
arcolinux-arc-archlinux-blue
arcolinux-arc-arcolinux-blue
arcolinux-arc-azul
arcolinux-arc-azure-dodger-blue
arcolinux-arc-blood
arcolinux-arc-blue-sky
arcolinux-arc-botticelli
arcolinux-arc-bright-lilac
arcolinux-arc-bright-lime-green
arcolinux-arc-carnation
arcolinux-arc-carolina-blue
arcolinux-arc-casablanca
arcolinux-arc-crimson
arcolinux-arc-dawn
arcolinux-arc-dracul
arcolinux-arc-emerald
arcolinux-arc-evopop
arcolinux-arc-fern
arcolinux-arc-fire
arcolinux-arc-froly
arcolinux-arc-havelock
arcolinux-arc-hibiscus
arcolinux-arc-light-blue-grey
arcolinux-arc-light-blue-surfn
arcolinux-arc-light-salmon
arcolinux-arc-mandy
arcolinux-arc-mantis
arcolinux-arc-medium-blue
arcolinux-arc-niagara
arcolinux-arc-nice-blue
arcolinux-arc-numix
arcolinux-arc-orchid
arcolinux-arc-pale-grey
arcolinux-arc-paper
arcolinux-arc-pink
arcolinux-arc-polo
arcolinux-arc-punch
arcolinux-arc-red-orange
arcolinux-arc-rusty-orange
arcolinux-arc-sky-blue
arcolinux-arc-slate-grey
arcolinux-arc-smoke
arcolinux-arc-soft-blue
arcolinux-arc-tacao
arcolinux-arc-tangerine
arcolinux-arc-tory
arcolinux-arc-vampire
arcolinux-arc-warm-pink
)

count=0

for name in "${directories[@]}"; do
	count=$[count+1]
	tput setaf 1;echo "Github "$count;tput sgr0;
	# if there is no folder then make one
	git clone https://github.com/arcolinux/$name
	echo "#################################################"
	echo "################  "$(basename `pwd`)" done"
	echo "#################################################"
done
