#!/bin/bash
#
##################################################################################################################
# Written to be used on 64 bits computers
# Author 	: 	Erik Dubois
# Website 	: 	http://www.erikdubois.be
##################################################################################################################
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################

theme_count=0

source = "/home/erik/.themes"
target = "/home/erik/ARCO/ARCOLINUX-ARC"

arrayname=(arcolinux-arc-blue-sky
arcolinux-arc-dawn
)

count=0

for name in $(ls -d /home/erik/ARCO/ARCOLINUX-ARC/arcolinux-arc*); do
  echo $name
  count=$[count+1]
  cd $target/$name/usr/share/themes
  mkdir -p /usr/share/themes
  echo "#################################################"
  echo "################  "$(basename `pwd`)" done"
  echo "#################################################"
  cd ..
done
exit 1
