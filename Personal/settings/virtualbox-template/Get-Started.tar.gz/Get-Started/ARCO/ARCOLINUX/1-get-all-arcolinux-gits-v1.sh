#!/bin/bash
#set -e
##################################################################################################################
# Author 	: Erik Dubois
# Website   : https://www.erikdubois.be
# Website   : https://www.alci.online
# Website	: https://www.arcolinux.info
# Website	: https://www.arcolinux.com
# Website	: https://www.arcolinuxd.com
# Website	: https://www.arcolinuxb.com
# Website	: https://www.arcolinuxiso.com
# Website	: https://www.arcolinuxforum.com
##################################################################################################################
#
#   DO NOT JUST RUN THIS. EXAMINE AND JUDGE. RUN AT YOUR OWN RISK.
#
##################################################################################################################
#tput setaf 0 = black 
#tput setaf 1 = red 
#tput setaf 2 = green
#tput setaf 3 = yellow 
#tput setaf 4 = dark blue 
#tput setaf 5 = purple
#tput setaf 6 = cyan 
#tput setaf 7 = gray 
#tput setaf 8 = light blue
##################################################################################################################

echo
tput setaf 3
echo "################################################################"
echo "################### Start"
echo "################################################################"
tput sgr0
echo

echo "This updates the existing githubs"
echo "Fill the array with the original folders first"

# use ls -d */ > list to get the list of the created githubs and copy/paste in

directories=(
archlinux-login-backgrounds/
archlinux-login-backgrounds-plain/
arcolinux-alacritty/
arcolinux-apps/
arcolinux-betterlockscreen/
arcolinux-betterlockscreen-dev/
arcolinux-bin/
arcolinux-candy-beauty/
arcolinux-candy-beauty-dev/
arcolinux-chadwm-pacman-hook/
arcolinux-common/
arcolinux-conky-collection/
arcolinux-conky-collection-plasma/
arcolinux-create-arc-themes/
arcolinux-cron/
arcolinux-desktop-trasher/
arcolinux-desktop-trasher-dev/
arcolinux-docs/
arcolinux-dusk-pacman-hook/
arcolinux-dwm-pacman-hook/
arcolinuxd-system-config/
arcolinuxd-welcome-app/
arcolinux-dwm-slstatus/
arcolinux-dwm-st/
arcolinux-faces/
arcolinux-fish/
arcolinux-fonts/
arcolinux-foot/
arcolinux-geany/
arcolinux-glava-config/
arcolinux-grub-theme-vimix/
arcolinux-grub-theme-vimix-dev/
arcolinux-gtk3-arcolinux-candy-beauty/
arcolinux-gtk3-sardi-arc/
arcolinux-gtk3-surfn-arc/
arcolinux-gtk3-surfn-arc-breeze/
arcolinux-gtk3-surfn-plasma-dark/
arcolinux-guake-autostart/
arcolinux-hyprland-profile/
arcolinux-icon-themes-fixer/
arcolinux-kitty/
arcolinux-kvantum/
arcolinux-kvantum-lxqt/
arcolinux-kvantum-plasma/
arcolinux-kvantum-theme-arc/
arcolinux-leftwm-themes/
arcolinux-leftwm-themes-community/
arcolinux-leftwm-theme-arise/
arcolinux-leftwm-theme-db/
arcolinux-leftwm-theme-db-comic/
arcolinux-leftwm-theme-db-color-dev/
arcolinux-leftwm-theme-db-scifi/
arcolinux-leftwm-theme-db-scifi-star/
arcolinux-leftwm-theme-db-nemesis/
arcolinux-leftwm-theme-doublebar/
arcolinux-leftwm-theme-docky/
arcolinux-leftwm-theme-eden/
arcolinux-leftwm-theme-fancy/
arcolinux-leftwm-theme-forest/
arcolinux-leftwm-theme-grayblocks/
arcolinux-leftwm-theme-greyblocks/
arcolinux-leftwm-theme-halo/
arcolinux-leftwm-theme-material/
arcolinux-leftwm-theme-matrix/
arcolinux-leftwm-theme-mesh/
arcolinux-leftwm-theme-parker/
arcolinux-leftwm-theme-pi/
arcolinux-leftwm-theme-sb-horror/
arcolinux-leftwm-theme-shades/
arcolinux-leftwm-theme-smooth/
arcolinux-leftwm-theme-space/
arcolinux-leftwm-theme-starwars/
arcolinux-local-applications/
arcolinux-local-applications-all-hide
arcolinux-local-applications-plasma-hide/
arcolinux-local-xfce4/
arcolinux-logo/
archlinux-logout/
archlinux-logout-dev/
arcolinux-logout-themes/
arcolinux-lxdm-theme-minimalo/
arcolinux-lxqt-applications-add/
arcolinux-lxqt-applications-hide/
arcolinux-mint-y-icons/
arcolinux-mirrorlist/
arcolinux-mirrorlist-spinoff/
arcolinux-neofetch/
arcolinux-newm-profile/
arcolinux-nitrogen/
arcolinux-nwg-drawer/
arcolinux-obmenu-generator/
arcolinux-obmenu-generator-minimal/
arcolinux-obmenu-generator-xtended/
arcolinux-on-the-road/
arcolinux-openbox-themes/
arcolinux-paleofetch/
arcolinux-paru/
arcolinux-pipemenus/
arcolinux-plank/
arcolinux-plank-themes/
arcolinux-plasma-arc-dark-candy/
arcolinux-plasma-nordic-darker-candy/
arcolinux-plasma-kservices/
arcolinux-polybar/
arcolinux-qt5/
arcolinux-qt5-plasma/
arcolinux-reflector-simple/
arcolinux-rofi/
arcolinux-rofi-themes/
arcolinux-root/
arcolinux-sddm-breeze/
arcolinux-sddm-breeze-minimal/
arcolinux-sddm-futuristic/
arcolinux-sddm-materia/
arcolinux-sddm-simplicity/
arcolinux-sddm-slice/
arcolinux-sddm-sugar-candy/
arcolinux-sddm-urbanlifestyle/
arcolinux-spices/
arcolinux-sway-profile/
arcolinux-sweet-mars/
arcolinux-system-config/
arcolinux-system-config-dev/
arcolinux-systemd-services/
arcolinux-systemd-services-dev/
arcolinux-system-installation/
arcolinux-system-installation-dev/
arcolinux-tellme/
arcolinux-termite-themes/
arcolinux-tint2/
arcolinux-tint2-themes/
archlinux-tweak-tool/
archlinux-tweak-tool-dev/
arcolinux-variety/
arcolinux-variety-autostart/
arcolinux-volumeicon/
arcolinux-wayfire-profile/
arcolinux-wayland-app-hooks/
arcolinux-wallpapers/
arcolinux-wallpapers-candy/
arcolinux-wallpapers-dual/
arcolinux-wayland-profile/
arcolinux-welcome-app/
arcolinux-welcome-app-deepin/
arcolinux-welcome-app-dev/
arcolinux-xfce-panel-profiles/
arcolinux-xlunch/
arcolinux-xmobar/
arcolinux-zsh/
sofirem/
sofirem-dev
)

count=0

for name in "${directories[@]}"; do
	count=$[count+1]
	tput setaf 1;echo "Github "$count;tput sgr0;
	# if there is no folder then make one
	git clone https://github.com/arcolinux/$name
	echo "#################################################"
	echo "################  "$(basename `pwd`)" done"
	echo "#################################################"
done

echo
tput setaf 3
echo "################################################################"
echo "################### End"
echo "################################################################"
tput sgr0
echo